"""Замеры времени, графики и оценка эмпирической сложности (Задания 2-5)."""
import json
import math
import random
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from search_algorithms import (linear_search, binary_search,
                               binary_search_recursive, interpolation_search,
                               dict_search)

SIZES = [100, 1_000, 10_000, 100_000, 1_000_000]
ALGS = ["linear", "binary_iter", "binary_rec", "interp", "dict"]


def measure(func, *args, repeat=5, number=1):
    """Минимальное время ОДНОГО вызова (с) за repeat прогонов.
    Если number > 1, внутри прогона функция вызывается number раз и время
    делится на number (повышает точность для очень быстрых операций)."""
    best = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        for _ in range(number):
            func(*args)
        t1 = time.perf_counter()
        best = min(best, (t1 - t0) / number)
    return best


def make_calls(data, d):
    """Функция + аргументы + число вызовов за прогон для каждого алгоритма."""
    n = len(data)
    return {
        "linear":      (linear_search, (data,), max(1, 20_000 // n)),
        "binary_iter": (binary_search, (data,), 1000),
        "binary_rec":  (binary_search_recursive, (data,), 1000),
        "interp":      (interpolation_search, (data,), 1000),
        "dict":        (dict_search, (d,), 10_000),
    }


def run_benchmark():
    """Задания 2 и 5. Возвращает словарь со всеми результатами."""
    random.seed(1)
    worst = {k: [] for k in ALGS}   # точный замер, худший случай (Задание 2)
    raw = {k: [] for k in ALGS}     # «наивный» замер: number=1, repeat=5
    cases = {k: {"best": [], "avg": [], "worst": []} for k in ALGS}

    for n in SIZES:
        data = sorted(random.sample(range(n * 10), n))   # уникальные значения
        d = {x: i for i, x in enumerate(data)}
        calls = make_calls(data, d)
        t_worst = data[-1]
        mid_item = data[(n - 1) // 2]   # первая проверка бинарного поиска: mid = (0 + n-1)//2
        t_best = {"linear": data[0], "binary_iter": mid_item,
                  "binary_rec": mid_item, "interp": data[0],
                  "dict": data[0]}
        rand_targets = [random.choice(data) for _ in range(20)]

        for name in ALGS:
            func, pre, num = calls[name]
            raw[name].append(measure(func, *pre, t_worst, repeat=5, number=1))
            tw = measure(func, *pre, t_worst, repeat=7, number=num)
            tb = measure(func, *pre, t_best[name], repeat=7, number=num)
            ta = sum(measure(func, *pre, t, repeat=3, number=num)
                     for t in rand_targets) / len(rand_targets)
            worst[name].append(tw)
            cases[name]["best"].append(tb)
            cases[name]["avg"].append(ta)
            cases[name]["worst"].append(tw)
        print(f"n = {n:>9}: " + ", ".join(
            f"{k}={worst[k][-1] * 1000:.5f} ms" for k in ALGS), flush=True)
    return worst, raw, cases


def estimate_growth(sizes, times):
    """p = log(t2/t1)/log(n2/n1) по двум последним точкам."""
    n1, n2 = sizes[-2], sizes[-1]
    t1, t2 = times[-2], times[-1]
    if t1 == 0 or n1 == 0:
        return float("nan")
    return math.log(t2 / t1) / math.log(n2 / n1)


def fit_growth(sizes, times):
    """Наклон МНК в лог-лог координатах по всем точкам."""
    xs = [math.log(n) for n in sizes]
    ys = [math.log(t) for t in times]
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    return (sum((x - mx) * (y - my) for x, y in zip(xs, ys))
            / sum((x - mx) ** 2 for x in xs))


def plot_results(sizes, results, fname, title):
    plt.figure(figsize=(10, 6))
    for name, times in results.items():
        plt.plot(sizes, times, marker="o", label=name)
    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("Размер массива n (log)")
    plt.ylabel("Время (с, log)")
    plt.title(title)
    plt.legend()
    plt.grid(True, which="both", alpha=0.3)
    plt.tight_layout()
    plt.savefig(fname, dpi=150)
    plt.close()


def plot_cases(sizes, cases, fname):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.6), sharey=False)
    styles = {"best": ("s", "--"), "avg": ("o", "-"), "worst": ("^", ":")}
    lab = {"best": "лучший", "avg": "средний", "worst": "худший"}
    for ax, name in zip(axes, ["linear", "binary_iter", "interp"]):
        for case, (m, ls) in styles.items():
            ax.plot(sizes, cases[name][case], marker=m, linestyle=ls, label=lab[case])
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_title(name); ax.set_xlabel("n"); ax.set_ylabel("Время (с)")
        ax.grid(True, which="both", alpha=0.3); ax.legend()
    plt.tight_layout()
    plt.savefig(fname, dpi=150)
    plt.close()


if __name__ == "__main__":
    worst, raw, cases = run_benchmark()
    p_last = {k: estimate_growth(SIZES, worst[k]) for k in ALGS}
    p_raw = {k: estimate_growth(SIZES, raw[k]) for k in ALGS}
    p_fit = {k: fit_growth(SIZES, worst[k]) for k in ALGS}
    for k in ALGS:
        print(f"{k:<12} p(последние точки)={p_last[k]:.3f}  "
              f"p(без повторов)={p_raw[k]:.3f}  p(МНК)={p_fit[k]:.3f}")
    plot_results(SIZES, worst, "search_benchmark.png",
                 "Зависимость времени поиска от размера массива")
    plot_results(SIZES, raw, "search_benchmark_raw.png",
                 "Тот же замер без усреднения по вызовам (number=1)")
    plot_cases(SIZES, cases, "search_cases.png")
    json.dump(dict(sizes=SIZES, worst=worst, raw=raw, cases=cases,
                   p_last=p_last, p_raw=p_raw, p_fit=p_fit),
              open("bench.json", "w"))
