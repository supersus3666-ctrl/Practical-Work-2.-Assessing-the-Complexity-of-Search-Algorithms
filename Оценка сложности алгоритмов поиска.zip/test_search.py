"""Юнит-тесты алгоритмов поиска (Задание 1)."""
import random
import unittest
from search_algorithms import (linear_search, binary_search,
                               binary_search_recursive, interpolation_search,
                               dict_search)

SORTED_FUNCS = [linear_search, binary_search, binary_search_recursive,
                interpolation_search]


class TestSearch(unittest.TestCase):
    def test_empty(self):
        for f in SORTED_FUNCS:
            self.assertEqual(f([], 5), -1, f.__name__)

    def test_single(self):
        for f in SORTED_FUNCS:
            self.assertEqual(f([7], 7), 0, f.__name__)
            self.assertEqual(f([7], 3), -1, f.__name__)

    def test_first_last_middle_absent(self):
        arr = [1, 3, 5, 7, 9, 11, 13, 15]
        for f in SORTED_FUNCS:
            self.assertEqual(f(arr, 1), 0, f.__name__)       # в начале
            self.assertEqual(f(arr, 15), 7, f.__name__)      # в конце
            self.assertEqual(f(arr, 7), 3, f.__name__)       # в середине
            for absent in (0, 4, 16, 100, -5):               # отсутствует
                self.assertEqual(f(arr, absent), -1, f.__name__)

    def test_all_equal(self):
        arr = [4, 4, 4, 4]
        for f in SORTED_FUNCS:
            self.assertEqual(arr[f(arr, 4)], 4, f.__name__)
            self.assertEqual(f(arr, 5), -1, f.__name__)

    def test_random_arrays(self):
        random.seed(0)
        for _ in range(300):
            n = random.randint(0, 10)
            arr = sorted(random.sample(range(30), n))
            for t in range(-1, 32):
                expected = arr.index(t) if t in arr else -1
                for f in SORTED_FUNCS:
                    self.assertEqual(f(arr, t), expected, (f.__name__, arr, t))

    def test_dict(self):
        arr = [2, 4, 6, 8]
        d = {x: i for i, x in enumerate(arr)}
        self.assertEqual(dict_search(d, 6), 2)
        self.assertEqual(dict_search(d, 5), -1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
