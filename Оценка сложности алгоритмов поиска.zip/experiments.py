"""Дополнительные эксперименты: Задание 6 и контрольные вопросы."""
import json
import math
import random
import sys

from benchmark import measure
from search_algorithms import (linear_search, binary_search,
                               interpolation_search, dict_search)


# ---------- КВ-1: бинарный поиск на неотсортированном массиве ----------
def unsorted_experiment(n=1000, trials=200):
    random.seed(5)
    wrong = total = 0
    for _ in range(trials):
        arr = random.sample(range(n * 10), n)          # НЕ отсортирован
        for t in random.sample(arr, 20):               # элемент точно есть
            total += 1
            if binary_search(arr, t) == -1:
                wrong += 1
    return wrong, total


# ---------- КВ-2 и КВ-5: число шагов binary vs interpolation ----------
def binary_steps(arr, target):
    left, right, steps = 0, len(arr) - 1, 0
    while left <= right:
        steps += 1
        mid = (left + right) // 2
        if arr[mid] == target:
            break
        if arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return steps


def interp_steps(arr, target):
    low, high, steps = 0, len(arr) - 1, 0
    while low <= high and arr[low] <= target <= arr[high]:
        steps += 1
        if arr[high] == arr[low]:
            break
        pos = low + ((target - arr[low]) * (high - low)) // (arr[high] - arr[low])
        if arr[pos] == target:
            break
        if arr[pos] < target:
            low = pos + 1
        else:
            high = pos - 1
    return steps


def steps_experiment():
    random.seed(7)
    rows = []
    for n in (1_000, 100_000, 1_000_000):
        data = sorted(random.sample(range(n * 10), n))
        targets = random.sample(data, 300)
        b = sum(binary_steps(data, t) for t in targets) / 300
        i = sum(interp_steps(data, t) for t in targets) / 300
        rows.append(dict(n=n, binary=b, interp=i))
    # плохие данные для интерполяции: почти все числа малы, одно огромное
    bad = []
    for n in (1_000, 10_000, 100_000):
        arr = list(range(n - 1)) + [10 ** 12]
        t = n - 2
        bad.append(dict(n=n, interp=interp_steps(arr, t), binary=binary_steps(arr, t)))
    return rows, bad


# ---------- КВ-4: где линейный поиск быстрее бинарного ----------
def small_n_experiment():
    random.seed(11)
    rows = []
    for n in (4, 8, 16, 32, 64, 128, 256):
        data = sorted(random.sample(range(n * 10), n))
        targets = [random.choice(data) for _ in range(30)]
        tl = sum(measure(linear_search, data, t, repeat=3, number=2000) for t in targets) / 30
        tb = sum(measure(binary_search, data, t, repeat=3, number=2000) for t in targets) / 30
        rows.append(dict(n=n, linear=tl, binary=tb))
    return rows


# ---------- Задание 6: dict против бинарного поиска ----------
def dict_vs_binary(n=1_000_000):
    random.seed(3)
    data = sorted(random.sample(range(n * 10), n))
    import time
    t0 = time.perf_counter()
    d = {x: i for i, x in enumerate(data)}
    build = time.perf_counter() - t0
    rt = [random.choice(data) for _ in range(20)]
    out = {}
    for case, target in (("худший (data[-1])", data[-1]), ("отсутствует", -1)):
        out[case] = dict(
            binary=measure(binary_search, data, target, repeat=7, number=2000),
            dict=measure(dict_search, d, target, repeat=7, number=20000))
    out["случайный"] = dict(
        binary=sum(measure(binary_search, data, t, repeat=3, number=2000) for t in rt) / 20,
        dict=sum(measure(dict_search, d, t, repeat=3, number=20000) for t in rt) / 20)
    mem = dict(list_bytes=sys.getsizeof(data), dict_bytes=sys.getsizeof(d))
    return out, build, mem


class BadKey:
    """Ключ с плохой хеш-функцией: все объекты попадают в одну корзину."""
    def __init__(self, v):
        self.v = v

    def __hash__(self):
        return 1

    def __eq__(self, other):
        return self.v == other.v


class GoodKey:
    def __init__(self, v):
        self.v = v

    def __hash__(self):
        return hash(self.v)

    def __eq__(self, other):
        return self.v == other.v


def collision_experiment():
    rows = []
    for n in (250, 500, 1000, 2000, 4000):
        bad = {BadKey(i): i for i in range(n)}
        good = {GoodKey(i): i for i in range(n)}
        kb, kg = BadKey(n - 1), GoodKey(n - 1)   # последний вставленный ключ
        tb = measure(bad.get, kb, repeat=5, number=20)
        tg = measure(good.get, kg, repeat=5, number=200)
        rows.append(dict(n=n, bad=tb, good=tg))
    return rows


if __name__ == "__main__":
    res = {}
    res["unsorted"] = unsorted_experiment()
    print("unsorted", res["unsorted"], flush=True)
    res["steps"], res["bad_steps"] = steps_experiment()
    print(res["steps"], res["bad_steps"], flush=True)
    res["small"] = small_n_experiment()
    print(res["small"], flush=True)
    res["dict_vs_bin"], res["build"], res["mem"] = dict_vs_binary()
    print(res["dict_vs_bin"], res["build"], res["mem"], flush=True)
    res["collisions"] = collision_experiment()
    print(res["collisions"], flush=True)
    json.dump(res, open("exp.json", "w"))


# ---------- КВ-4 (дополнение): когда «худшая» асимптотика выигрывает ----------
def sort_vs_linear_experiment():
    """Один запрос в НЕотсортированном массиве: линейный поиск против
    «сортировка + бинарный поиск», и встроенный list.index (C) против
    бинарного поиска на Python."""
    random.seed(13)
    rows = []
    for n in (4, 8, 16, 32, 64, 128, 256, 1000):
        arr = random.sample(range(n * 10), n)
        srt = sorted(arr)
        targets = [random.choice(arr) for _ in range(30)]
        lin = sum(measure(linear_search, arr, t, repeat=3, number=1000) for t in targets) / 30
        sb = sum(measure(lambda a, t: binary_search(sorted(a), t), arr, t, repeat=3, number=1000)
                 for t in targets) / 30
        idx = sum(measure(arr.index, t, repeat=3, number=1000) for t in targets) / 30
        bs = sum(measure(binary_search, srt, t, repeat=3, number=1000) for t in targets) / 30
        rows.append(dict(n=n, linear=lin, sort_binary=sb, list_index=idx, binary=bs))
    return rows
